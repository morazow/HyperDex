#!/bin/bash

rm -rf hyperclient-*
rm -rf HyperClientLog.INFO

#echo "STARTING ALL"
#cd ../tests
#./deploy_all.sh
#cd ../runs-tests
#
#sleep 1
#
for i in 1 2
do

    echo "CREATING SPACE"
    python hotels_space_$i.py

    echo "LOADING DATA"
    python load.py
    
    sleep 1

    echo "SEARCHING.."
    python search-all.py > result-$i.txt
    mv configuration.txt config-$i.txt
    cp HyperClientLog.INFO info-$i.txt

   echo "DELETE SPACE"
    python remove_space.py

    sleep 1
done

