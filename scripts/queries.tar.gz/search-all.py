 #!/usr/bin/python

import json
import sys
import hyperclient
import time
from random import randint
from multiprocessing import Process

MAX_OPS   = 1000
MAX_THR   = 500
TotalTime = 0

def query1(arg):
    c = hyperclient.Client('172.31.0.5', 1982)
    if arg%2 == 0:
        for i in xrange(MAX_OPS):
            res1 = [x for x in c.search_describe('hotels', {'location':'Lisbon'})]
    else:
        for i in xrange(MAX_OPS):
            res1 = [x for x in c.search_describe('hotels', {'location':'Paris'})]

def query2():
    c = hyperclient.Client('172.31.0.5', 1982)
    for i in xrange(MAX_OPS):
        res2 = [x for x in c.search('hotels', {'location':'Paris'})]
        #res2 = [x for x in c.search('hotels', {'prices':(300.0,500.0)})]

def query3():
    c = hyperclient.Client('172.31.0.5', 1982)
    for i in xrange(MAX_OPS):
        res3 = [x for x in c.search('hotels', {'prices':(20.0,900.0)})]

def query4():
    c = hyperclient.Client('172.31.0.5', 1982)
    for i in xrange(MAX_OPS):
        res4 = [x for x in c.search('hotels', {'stars':3})]


def query5():
    c = hyperclient.Client('172.31.0.5', 1982)
    for i in xrange(MAX_OPS):
        res5 = [x for x in c.search('hotels', {'stars':4, 'prices':250.0})]


def query6():
    c = hyperclient.Client('172.31.0.5', 1982)
    for i in xrange(MAX_OPS):
        res6 = [x for x in c.search('hotels', {'stars':(4,5), 'prices':(300.0,400.0)})]

def query7():
    c = hyperclient.Client('172.31.0.5', 1982)
    for i in xrange(MAX_OPS):
        res7 = [x for x in c.search('hotels', {'stars':(1,5), 'prices':(20.0,900.0)})]

def query8():
    c = hyperclient.Client('172.31.0.5', 1982)
    for i in xrange(MAX_OPS):
        res8 = [x for x in c.search('hotels', {'stars':3, 'prices':300.0, 'ratings':7.0})]

def query9():
    c = hyperclient.Client('172.31.0.5', 1982)
    for i in xrange(MAX_OPS):
        res9 = [x for x in c.search('hotels', {'prices':350.0, 'ratings':7.5})]


def wrapper(func):
    processes = []
    for i in range(MAX_THR):
        p = Process(target=func, args=(i,))
        processes.append(p)

    start_time = time.time()
    for t in processes:
        t.start();

    for t in processes:
        t.join()
    
    start_time = time.time() - start_time
    print start_time, ",", (MAX_OPS * MAX_THR) / start_time

if __name__ == "__main__":

    ttime = time.time()
    wrapper(query1)
#    wrapper(query2)
#    wrapper(query3)
#    wrapper(query4)
#    wrapper(query5)
#    wrapper(query6)
#    wrapper(query7)
#    wrapper(query8)
#    wrapper(query9)
    ttime = time.time() - ttime;

    print ttime

