#!/usr/bin/python
import hyperclient

c = hyperclient.Client('172.31.0.5', 1982)
c.add_space('''
        space hotels
        key k
        attributes string name, float prices, float ratings, int reviews, int stars, 
                   string location
        tolerate 0 failure
        ''')
